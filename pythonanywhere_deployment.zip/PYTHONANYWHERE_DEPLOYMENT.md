# Deploying to PythonAnywhere

This guide explains how to deploy your Flask application to PythonAnywhere.

## Prerequisites

1. A PythonAnywhere account (https://www.pythonanywhere.com/)
2. Your PythonAnywhere username (in your case, it's `minhaajt`)

## Deployment Steps

### 1. Upload Files to PythonAnywhere

1. Log in to your PythonAnywhere account
2. Go to the **Files** tab
3. Create a new directory called `mysite` (or any name you prefer)
4. Upload the following files to this directory:
   - [app.py](file://c:\Users\minha\work\Server-mysql\app.py)
   - [.env](file://c:\Users\minha\work\Server-mysql\.env)
   - [requirements.txt](file://c:\Users\minha\work\Server-mysql\requirements.txt)
   - [config.py](file://c:\Users\minha\work\Server-mysql\config.py)
   - [pythonanywhere_wsgi.py](file://c:\Users\minha\work\Server-mysql\pythonanywhere_wsgi.py)

### 2. Install Dependencies

1. Go to the **Consoles** tab
2. Start a new Bash console
3. Run the following commands:
   ```bash
   cd /home/minhaajt/mysite
   pip install -r requirements.txt
   ```

### 3. Configure the Web App

1. Go to the **Web** tab
2. Click **Add a new web app**
3. Choose **Manual configuration** (not the Flask auto-configurator)
4. Select **Python 3.8** or later
5. Click **Next** and then **Done**

### 4. Configure Web App Settings

After creating the web app, you'll need to modify some settings:

1. In the **Code** section:
   - Set **Source code** to `/home/minhaajt/mysite`
   - Set **WSGI configuration file** to `/home/minhaajt/mysite/pythonanywhere_wsgi.py`

2. In the **Virtualenv** section:
   - Set the path to your virtualenv (optional but recommended)

3. In the **Static files** section (optional):
   - You can add static file mappings if needed

### 5. Update WSGI Configuration

Make sure your WSGI configuration file (`pythonanywhere_wsgi.py`) has the correct path:
```python
import sys
import os

# Add your project directory to the sys.path
path = '/home/minhaajt/mysite'
if path not in sys.path:
    sys.path.append(path)

os.chdir(path)
from app import app as application

if __name__ == '__main__':
    application.run()
```

### 6. Reload the Web App

1. Scroll to the top of the web app configuration page
2. Click the **Reload** button
3. Your app should now be accessible at https://minhaajt.pythonanywhere.com

## API Endpoints

Once deployed, your application will have the following endpoints:
- `https://minhaajt.pythonanywhere.com/` - Home page
- `https://minhaajt.pythonanywhere.com/books` - Get all books
- `https://minhaajt.pythonanywhere.com/products` - Get all products

## Troubleshooting

If you encounter issues:

1. Check the error log in the **Web** tab
2. Make sure all dependencies are installed
3. Verify database connection settings in the [.env](file://c:\Users\minha\work\Server-mysql\.env) file
4. Ensure the WSGI file path is correct

## Notes

- PythonAnywhere may have specific requirements for database connections
- Make sure your database allows connections from PythonAnywhere IPs
- The free tier has some limitations on external connections