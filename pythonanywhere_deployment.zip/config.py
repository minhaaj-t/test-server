import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    """Base configuration class."""
    # Database configuration
    DB_HOST = os.getenv('DB_HOST', 'db.fr-pari1.bengt.wasmernet.com')
    DB_PORT = os.getenv('DB_PORT', '10272')
    DB_NAME = os.getenv('DB_NAME', 'library_management')
    DB_USER = os.getenv('DB_USER', '7e4ca751759c8000463db46b28a7')
    DB_PASSWORD = os.getenv('DB_PASSWORD', '068b7e4c-a751-77af-8000-cb2911e1c700')
    
    # SQLAlchemy configuration
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False