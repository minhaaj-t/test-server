# Flask MySQL Server

A Python Flask application that connects to a MySQL database and provides API endpoints for a library management system.

## Setup

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Set up your database credentials in the `.env` file:
   ```
   DB_HOST=db.fr-pari1.bengt.wasmernet.com
   DB_PORT=10272
   DB_NAME=library_management
   DB_USER=7e4ca751759c8000463db46b28a7
   DB_PASSWORD=068b7e4c-a751-77af-8000-cb2911e1c700
   ```

## Running the Server Locally

Start the Flask server:
```
python app.py
```

The server will be available at `http://localhost:5000`

## API Endpoints

- `GET /` - Home page
- `GET /books` - Retrieve all books in the library
- `GET /products` - Retrieve all products

## Database Schema

The application works with the existing database schema and adds:
- Books table with detailed information about library books
- Products table with information about products
- Related tables for departments, categories, users, etc.

## Features

- Connects to remote MySQL database
- Retrieves book and product information through REST API
- Inserts dummy data if tables are empty
- Handles existing database constraints properly
- Creates new tables as needed

## Dummy Data

The application automatically inserts sample data:
- 3 sample books in the books table
- 5 sample products in the products table

## Deploying to PythonAnywhere

To deploy this application to PythonAnywhere at https://minhaajt.pythonanywhere.com:

1. Upload the following files to your PythonAnywhere account:
   - [app_pythonanywhere.py](file://c:\Users\minha\work\Server-mysql\app_pythonanywhere.py) (simplified version for PythonAnywhere)
   - [.env](file://c:\Users\minha\work\Server-mysql\.env) (database credentials)
   - [requirements.txt](file://c:\Users\minha\work\Server-mysql\requirements.txt) (dependencies)
   - [pythonanywhere_wsgi.py](file://c:\Users\minha\work\Server-mysql\pythonanywhere_wsgi.py) (WSGI configuration)

2. Install dependencies in a PythonAnywhere console:
   ```
   pip install -r requirements.txt
   ```

3. Configure your web app in the PythonAnywhere Web tab:
   - Source code: `/home/minhaajt/mysite`
   - WSGI configuration file: `/home/minhaajt/mysite/pythonanywhere_wsgi.py`

4. Reload your web app

See [PYTHONANYWHERE_DEPLOYMENT.md](file://c:\Users\minha\work\Server-mysql\PYTHONANYWHERE_DEPLOYMENT.md) for detailed deployment instructions.