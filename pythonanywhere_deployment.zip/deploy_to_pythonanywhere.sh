#!/bin/bash

# Deployment script for PythonAnywhere
# This script provides guidance for deploying to PythonAnywhere

echo "=== PythonAnywhere Deployment Script ==="
echo "This script provides instructions for deploying your Flask app to PythonAnywhere"
echo ""

echo "Step 1: Log in to PythonAnywhere"
echo "  - Go to https://www.pythonanywhere.com/"
echo "  - Log in with your credentials"
echo ""

echo "Step 2: Upload files"
echo "  - Go to the 'Files' tab"
echo "  - Create a directory named 'mysite'"
echo "  - Upload these files to the 'mysite' directory:"
echo "    * app_pythonanywhere.py"
echo "    * .env"
echo "    * requirements.txt"
echo ""

echo "Step 3: Install dependencies"
echo "  - Go to the 'Consoles' tab"
echo "  - Start a new Bash console"
echo "  - Run these commands:"
echo "    cd /home/minhaajt/mysite"
echo "    pip install -r requirements.txt"
echo ""

echo "Step 4: Configure the web app"
echo "  - Go to the 'Web' tab"
echo "  - Click 'Add a new web app'"
echo "  - Choose 'Manual configuration'"
echo "  - Select Python 3.8 or later"
echo ""

echo "Step 5: Configure web app settings"
echo "  - In the 'Code' section:"
echo "    * Set 'Source code' to /home/minhaajt/mysite"
echo "    * Set 'WSGI configuration file' to /home/minhaajt/mysite/pythonanywhere_wsgi.py"
echo ""

echo "Step 6: Update WSGI configuration"
echo "  - Edit the WSGI file to match the pythonanywhere_wsgi.py content"
echo ""

echo "Step 7: Reload the web app"
echo "  - Click the 'Reload' button"
echo "  - Your app will be available at https://minhaajt.pythonanywhere.com"
echo ""

echo "=== Deployment Complete ==="