from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
import os

# Initialize Flask app
app = Flask(__name__)

# Database configuration for PythonAnywhere
# These should match your .env file but are hardcoded here for PythonAnywhere compatibility
DB_HOST = 'db.fr-pari1.bengt.wasmernet.com'
DB_PORT = '10272'
DB_NAME = 'library_management'
DB_USER = '7e4ca751759c8000463db46b28a7'
DB_PASSWORD = '068b7e4c-a751-77af-8000-cb2911e1c700'

app.config['SQLALCHEMY_DATABASE_URI'] = (
    f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Define a model that matches the existing books table structure
class Book(db.Model):
    __tablename__ = 'books'
    
    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    author = db.Column(db.String(255), nullable=False)
    image = db.Column(db.String(255), nullable=True)
    isbn = db.Column(db.String(255), nullable=False)
    language = db.Column(db.String(255), nullable=False)
    published_year = db.Column(db.Integer, nullable=False)
    availability = db.Column(db.Enum('available', 'checked-out'), nullable=False)
    category = db.Column(db.Enum('fiction', 'non-fiction', 'academic', 'science', 'technology', 
                                'history', 'biography', 'children', 'reference', 'other'), nullable=False)
    publisher = db.Column(db.String(255), nullable=True)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Numeric(8, 2), nullable=True)
    total_copies = db.Column(db.Integer, nullable=False)
    available_copies = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, nullable=True)
    department = db.Column(db.String(255), nullable=True)
    book_overview = db.Column(db.Text, nullable=True)
    page_images = db.Column(db.Text, nullable=True)
    
    def __repr__(self):
        return f'<Book {self.name}>'

# Define a model for products table
class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    stock_quantity = db.Column(db.Integer, nullable=False, default=0)
    image_url = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Product {self.name}>'

# Define a simple route
@app.route('/')
def index():
    return '<h1>Library Management System</h1><p>Flask server running on PythonAnywhere</p>'

# API endpoint to get all books
@app.route('/books')
def get_books():
    books = Book.query.all()
    books_list = []
    for book in books:
        books_list.append({
            'id': book.id,
            'name': book.name,
            'author': book.author,
            'isbn': book.isbn,
            'published_year': book.published_year,
            'availability': book.availability,
            'category': book.category
        })
    return {'books': books_list}

# API endpoint to get all products
@app.route('/products')
def get_products():
    products = Product.query.all()
    products_list = []
    for product in products:
        products_list.append({
            'id': product.id,
            'name': product.name,
            'description': product.description,
            'price': float(product.price) if product.price else None,
            'category': product.category,
            'stock_quantity': product.stock_quantity,
            'image_url': product.image_url
        })
    return {'products': products_list}

# This is important for PythonAnywhere deployment
if __name__ == '__main__':
    app.run(debug=False)