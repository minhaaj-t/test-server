# This file is used by PythonAnywhere to run the Flask app
# It's a WSGI entry point for PythonAnywhere deployment

import sys
import os

# Add the current directory to Python path
path = '/home/minhaajt/mysite'
if path not in sys.path:
    sys.path.append(path)

# Change to the project directory
os.chdir(path)

# Import the Flask app
from app import app as application

# This is the WSGI callable that PythonAnywhere will use
if __name__ == '__main__':
    application.run()